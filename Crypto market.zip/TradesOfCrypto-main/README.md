# TradesOfCrypto
Trades of Crypto is a WebApp which can be used to Track All the Crypto's Current price, Volumes Trading , Market Cap and Change in price(in terms of percent) in INR.
User can search for any crypto coin and the live information will be displayed. Real time data of each coin is updated !


# Live Link 
Link : https://tradesofcrypto.netlify.app/

# Screenshots
![Screenshot (524)](https://user-images.githubusercontent.com/104431269/176975449-02291276-0ca3-4e08-ab9f-22d5e6395e22.png)
![Screenshot (522)](https://user-images.githubusercontent.com/104431269/176975455-c38c2647-c541-4a99-b53d-9e236b86e24f.png)
![Screenshot (523)](https://user-images.githubusercontent.com/104431269/176975461-7f1bceee-e8df-4232-b565-81ad9fea946d.png)

# Tools Used 
The front-end is made entirely with the help of React Js. APIs from Coingecko was used to retrieve the data .Axios was used to integrate crypto API with the WebApp. 
